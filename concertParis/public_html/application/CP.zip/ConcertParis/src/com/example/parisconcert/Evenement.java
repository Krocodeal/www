package com.example.parisconcert;

import java.text.DateFormat;
import java.util.HashMap;
import java.util.List;


public class Evenement extends DAOEvenement{
	
		private int Evenement_ID;
		private String Evenement_Libelle;
		private String Evenement_Date;
		private String Evenement_Prix;
		private String Evenement_Description;
		private String Evenement_Lieu_Libelle;
		private String Evenement_Adresse;
		private String Evenement_Photo_Url;
		
		public Evenement()
		{
			super();	
		}
		public Evenement(String id, String libelle, String date, String prix, String des, String lieu, String adr, String url )
		{
			setEvenement_ID(Integer.parseInt(id));
			setEvenement_Libelle(libelle);
			setEvenement_Date(date);
			setEvenement_Prix(prix);
			setEvenement_Description(des);
			setEvenement_Lieu_Libelle(lieu);
			setEvenement_Adresse(adr);
			setEvenement_Photo_Url(url);
		}
		
		
		public void getEvenementById(String Id)
		{
			String[] unEvenement ;
			unEvenement = super.DAOgetEvenementById(Id);
			setEvenement_ID(Integer.parseInt(unEvenement[0]));
			setEvenement_Libelle(unEvenement[1]);
			setEvenement_Date(unEvenement[2]);
			setEvenement_Prix(unEvenement[3]);
			setEvenement_Description(unEvenement[4]);
			setEvenement_Lieu_Libelle(unEvenement[5]);
			setEvenement_Adresse(unEvenement[6]);
			setEvenement_Photo_Url(unEvenement[7]);
			
		}
		
		public List<HashMap<String, String>> getListeEvenement()
		{
			return super.getListeEvenement();		
		}		
		
		private String NullToString(String Valeur)
		{
			if(Valeur == "null")
			{
				Valeur = "";
			}
			return Valeur;
		}



		public int getEvenement_ID() {
			return Evenement_ID;
		}



		public void setEvenement_ID(int evenement_ID) {
			Evenement_ID = evenement_ID;
		}



		public String getEvenement_Libelle() {
			return Evenement_Libelle;
		}



		public void setEvenement_Libelle(String evenement_Libelle) {
			Evenement_Libelle = evenement_Libelle;
		}



		public String getEvenement_Date() {
			return Evenement_Date;
		}



		public void setEvenement_Date(String evenement_Date) {
			Evenement_Date = evenement_Date;
		}



		public String getEvenement_Prix() {
			return Evenement_Prix;
		}



		public void setEvenement_Prix(String evenement_Prix) {
			Evenement_Prix = evenement_Prix;
		}



		public String getEvenement_Description() {
			return Evenement_Description;
		}



		public void setEvenement_Description(String evenement_Description) {
			Evenement_Description = evenement_Description;
		}



		public String getEvenement_Lieu_Libelle() {
			return Evenement_Lieu_Libelle;
		}



		public void setEvenement_Lieu_Libelle(String evenement_Lieu_Libelle) {
			Evenement_Lieu_Libelle = evenement_Lieu_Libelle;
		}



		public String getEvenement_Adresse() {
			return Evenement_Adresse;
		}



		public void setEvenement_Adresse(String evenement_Adresse) {
			Evenement_Adresse = evenement_Adresse;
		}



		public String getEvenement_Photo_Url() {
			return Evenement_Photo_Url;
		}



		public void setEvenement_Photo_Url(String evenement_Photo_Url) {
			Evenement_Photo_Url = evenement_Photo_Url;
		}
	}

