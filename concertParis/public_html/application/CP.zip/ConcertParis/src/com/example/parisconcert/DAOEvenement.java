package com.example.parisconcert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

public class DAOEvenement extends DAO {
	
	private String[] unEvenement;
	private String URL;
	ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
	
	public DAOEvenement()
	{
		super("",new ArrayList<NameValuePair>());
	}
	public String[] DAOgetEvenementById(String Param){

		this.URL = "http://concertparis.net/mobile/detailconcert.php";
		nameValuePairs.add(new BasicNameValuePair("E_ID",Param));
		super.setParametre(this.nameValuePairs);
		super.setURL(URL);
		try
		{	
			JSONArray jArray = new JSONArray(super.readResult());
			JSONObject json_data = jArray.getJSONObject(0);	
			this.unEvenement = new String[]{
					json_data.getString("EVENEMENT_ID"),
					json_data.getString("EVENEMENT_Libelle"),
					json_data.getString("EVENEMENT_Date"),
					json_data.getString("EVENEMENT_Prix"),
					json_data.getString("EVENEMENT_Description"),
					json_data.getString("LIEU_Libelle"),
					json_data.getString("LIEU_Adresse"),
					json_data.getString("PHOTO_Url"),
					};			
			
		}catch(JSONException e)
		{
		}
		return unEvenement;
	}
	
	public  List<HashMap<String, String>> getListeEvenement(){
		this.URL = "http://concertparis.net/mobile/listerconcerts.php";
		super.setParametre(this.nameValuePairs);
		super.setURL(URL);
	        // prepare the list of all records
	        List<HashMap<String, String>> lesEvenements = new ArrayList<HashMap<String, String>>();
	        JSONArray jArray;
			try {
				jArray = new JSONArray(super.readResult());
				Log.e("jason ", "avant la boucle");
				for(int i = 0; i < jArray.length(); i++){
		        	JSONObject json_data = jArray.getJSONObject(i);
					HashMap<String, String> map = new HashMap<String, String>();
		            map.put("Evenement_ID", "" + json_data.getString("EVENEMENT_ID"));
		            map.put("Evenement_Titre", json_data.getString("EVENEMENT_Libelle"));
		            map.put("Evenement_Date", json_data.getString("EVENEMENT_Date"));
		            Log.e("jason "+ i +" :", json_data.getString("EVENEMENT_Libelle"));
		            if(map!=null)
		            {
		            	lesEvenements.add(map);
		            }
		            
		            
		        }
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
	        
	        return lesEvenements;
	}

}
