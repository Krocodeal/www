package com.example.parisconcert;

import com.example.parisconcert.DAOUtilisateur;



public class Utilisateur extends DAOUtilisateur{
	
	private String Utilisateur_Id;
	private String Utilisateur_Mail;
	private String Utilisateur_Mdp;
	
	public Utilisateur()
	{
		super();
	}
	
	public int checkUtilisateur(String Utilisateur_Identifiant,String Utilisateur_Mdp)
	{
		return super.checkIdentifiant(Utilisateur_Identifiant, Utilisateur_Mdp);
	}
	public String getUtilisateur_Id() {
		return Utilisateur_Id;
	}
	public void setUtilisateur_Id(String utilisateur_Id) {
		Utilisateur_Id = utilisateur_Id;
	}

	public String getUtilisateur_Mail() {
		return Utilisateur_Mail;
	}

	public void setUtilisateur_Mail(String utilisateur_Mail) {
		Utilisateur_Mail = utilisateur_Mail;
	}

	public String getUtilisateur_Mdp() {
		return Utilisateur_Mdp;
	}

	public void setUtilisateur_Mdp(String utilisateur_Mdp) {
		Utilisateur_Mdp = utilisateur_Mdp;
	}
	
}
