package com.example.parisconcert;

import java.util.HashMap;
import java.util.List;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class Annuaire extends Connexion implements OnItemClickListener{
		
		TextView txt;
		ListView ListView;
		Intent activityChangeIntent;
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			
			
			
			
			setContentView(R.layout.activity_annuaire);
			ListView lv= (ListView)findViewById(R.id.list);
		
			//r�cup�ration du bouton gr�ce �  son ID
			//Button button = (Button) findViewById(R.id.ButtonEnvoyer);
			// create the grid item mapping
			
			// fill in the grid_item layout
			Evenement unEvenement = new Evenement();
			List<HashMap<String, String>> lesE = unEvenement.getListeEvenement();
	
			
			String[] from = new String[] {"Evenement_ID", "Evenement_Titre", "Evenement_Date"};
			int[] to = new int[] { R.id.Evenement_ID, R.id.Evenement_Titre, R.id.Evenement_Date};
		
			
			SimpleAdapter adapter = new SimpleAdapter(Annuaire.this,lesE, R.layout.grid_item, from, to);
			lv.setAdapter(adapter);
			//setContentView(lv); 
			 activityChangeIntent = new Intent(this, Detail.class);
			
			lv.setOnItemClickListener(this);      
		}
		public boolean onCreateOptionsMenu(Menu menu)
		{
			super.onCreateOptionsMenu(menu);
			//MenuInflater inflater = getMenuInflater();
			//inflater.inflate(R.menu.menu, menu);
			return true;
		}
		public boolean onOptionsItemSelected(MenuItem item)
		{
		    //switch (item.getItemId())
		    //{
		        //case R.id.back_title:
		        //    startActivity(new Intent(this, MainActivity.class));
		        return true;
		    //}
		  //return false;
		}
		@Override
		public void onItemClick(AdapterView<?> adapterView, View view, int position,long arg3) {
			String  U_id = ((TextView)view.findViewById(R.id.Evenement_ID)).getText().toString();
			Toast.makeText(getBaseContext(), U_id, Toast.LENGTH_LONG).show();
			
			activityChangeIntent.putExtra("Evenement_ID",U_id);
			startActivity(activityChangeIntent);
			
			
		}
	}

	

