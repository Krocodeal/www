package com.example.parisconcert;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Connexion extends Activity {
	
	EditText mailcontent, mdpcontent;
	Button connexion;
	TextView info;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_connexion);
		
		Button connexion = (Button) findViewById(R.id.connexion);
		
		connexion.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	
                // Perform action on click    
            	TextView info = (TextView)findViewById(R.id.info);
            	EditText mailcontent = (EditText)findViewById(R.id.mailcontent);
            	EditText mdpcontent = (EditText)findViewById(R.id.mdpcontent);
            	
            	if(mailcontent.getText().toString().equals("") || mdpcontent.getText().toString().equals(""))
            	{
            		info.setText("Erreur, veuillez remplir tous les champs.");            		
            	}
            	else
            	{
            		Utilisateur unUtilisateur = new Utilisateur();
            		switch(unUtilisateur.checkUtilisateur(mailcontent.getText().toString(), mdpcontent.getText().toString()))
            		{
	            		case 1:
	            			info.setText("L'utilisateur est bien identifi�.");
	            			Intent activityChangeIntent = new Intent(Connexion.this, Annuaire.class);
	                        Connexion.this.startActivity(activityChangeIntent);
	            			break;
	            		case 0:
	            			info.setText("Les identifiants renseign�s ne sont pas correct.");
	            			break;
            		}
            		
            	}
                
            }
        });
	}
}