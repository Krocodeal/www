package com.example.parisconcert;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class Detail extends Annuaire {
	
	/*ImageView image = (ImageView) findViewById(R.id.photourl);*/
	private TextView libelle ,description ,lieu, adresse , date , prix ;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_detail);
		libelle = (TextView) findViewById(R.id.libelle);
		description = (TextView) findViewById(R.id.description);
		lieu = (TextView) findViewById(R.id.lieu);
		adresse = (TextView) findViewById(R.id.adresse);
		date = (TextView) findViewById(R.id.date);
		prix = (TextView) findViewById(R.id.prix);
		String E_Id = getIntent().getStringExtra("Evenement_ID");
		Evenement unEvenement = new Evenement();
		unEvenement.getEvenementById(E_Id);
		
		libelle.setText(unEvenement.getEvenement_Libelle());
		description.setText(unEvenement.getEvenement_Description());
		lieu.setText(unEvenement.getEvenement_Lieu_Libelle());
		adresse.setText(unEvenement.getEvenement_Adresse());
		date.setText(unEvenement.getEvenement_Date());
		prix.setText(unEvenement.getEvenement_Prix());
		
	}
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.detail, menu);
		return true;
	}
	public boolean onOptionsItemSelected(MenuItem item)
	{
	  return false;
	}

}
